package com.Employee;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Employee.configuration.EmployeeConfiguration;
import com.Employee.entities.Document;
import com.Employee.entities.Employee;

public class App {
	public static void main(String[] args) {
//        System.out.println("Hello World!");

//        Document doc = new Document();
//        doc.setDocument_name("Pan Card, Aadhar, Certificate, Photo");
//
//        Employee emp = new Employee();
//        emp.setEmployee_name("Sushree");
//        emp.setPhoneNumber("7845645678");
//        emp.setDept("QA");
//        emp.setSalary(10000.0);
//        emp.setDocument(doc);
//
//        Employee emp1 = new Employee();
//        emp1.setEmployee_name("Swagatika");
//        emp1.setPhoneNumber("8765476554");
//        emp1.setDept("HR");
//        emp1.setSalary(15000.0);
//        emp1.setDocument(doc);
//
//        List<Employee> employees = new ArrayList<>();
//        employees.add(emp);
//        employees.add(emp1);
//
//        doc.setEmployees(employees);
//
//        saveDocument(doc); // This saves both document and employees
//    }
//
//    public static void saveDocument(Document doc) {
//        Session session = EmployeeConfiguration.getSessionFactory().openSession();
//        Transaction trn = session.beginTransaction();
//        session.save(doc);  // CascadeType.ALL will save employees too
//        trn.commit();
//        session.close();
//        System.out.println("Document and associated Employees saved.");
//   }
//        Document doc = new Document();
//        doc.setDocumentName("PAN Card");
//        doc.setId(5l);
//        List<Employee> empList=Arrays.asList(new Employee("PUPU", doc),new Employee("PUPULU", doc));
//        for(Employee emp:empList) {
//        	saveEmployee(emp);;
		// }
//        Employee emp = new Employee();
//        emp.setEmployee_Name("Sushree1");
//        emp.setDocument(doc);  // Set the relation
//      saveDocument(doc); 
//        doc.setEmployees(emp);  // Optional (only if bidirectional)
//        saveEmployee(emp);

		List<Document> docList1 = Arrays.asList(new Document("PAN", "DHDSDNSDS"),
				new Document("ADDHAR", "67672771283712"));
		// Create documents
//            Document doc1 = new Document();
//            doc1.setDocumentName("PAN CARD");
//            doc1.setDocumentNo("CHSDN8888");
//
//            Document doc2 = new Document();
//            doc2.setDocumentName("Aadhar Card");
//            doc2.setDocumentNo("");
//
//            Document doc3 = new Document();
//            doc3.setDocumentName("Photo");

		// Create employees and associate with documents
		Employee emp1 = new Employee();
		emp1.setEmployee_Name("Sushree");
		emp1.setDocumentList(docList1);
		saveEmployee(emp1);

//            Employee emp2 = new Employee();
//            emp2.setEmployee_Name("Suprit");
//            emp2.setDocument(doc1);
//
//            Employee emp3 = new Employee();
//            emp3.setEmployee_Name("Vikash");
//            emp3.setDocument(doc2);

		// Assign employees to documents (optional if bidirectional)
//            doc1.setEmployees(Arrays.asList(emp1, emp2));
//            doc2.setEmployees(Arrays.asList(emp3));
//            doc2.setEmployees(Arrays.asList(emp2));
//             Save documents (will cascade employees)
//            saveDocument(doc1);
//            saveDocument(doc2);
//            saveDocument(doc3); // This one has no employees
//       
//            List<Employee> empList=Arrays.asList(new Employee( null, "PUPU", doc1),new Employee(null, "PUPULU", doc2));
//        
//        }

//	public static void saveDocument(Document doc, Document doc1, Document doc2) {
//		
//        Session session = EmployeeConfiguration.getSessionFactory().openSession();
//        Transaction tx = session.beginTransaction();
//
//        session.save(doc);  // CascadeType.ALL will save doc too
//
//        tx.commit();
//        session.close();
//
//        System.out.println("Employee and Document saved successfully.");
//	}
//public static void saveEmployee(Employee doc, Employee emp1, Employee emp2) {
//		
//        Session session = EmployeeConfiguration.getSessionFactory().openSession();
//        Transaction tx = session.beginTransaction();
//
//        session.save(doc);  // CascadeType.ALL will save doc too
//
//        tx.commit();
//        session.close();
// 
//        System.out.println("Employee and Document saved successfully.");
//

//public static void saveDocument(Document doc) {
//    Session session = EmployeeConfiguration.getSessionFactory().openSession();
//    Transaction tx = session.beginTransaction();
//    session.save(doc);  // Will cascade and save employees
//    tx.commit();
//    session.close();
//    System.out.println("Saved document: " + doc.getDocumentName());
	}

	public static void saveEmployee(Employee emp) {

		Session session = EmployeeConfiguration.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();

		session.save(emp); // CascadeType.ALL will save doc too

		tx.commit();
		session.close();

		System.out.println("Employee and Document saved successfully.");
	}
}
