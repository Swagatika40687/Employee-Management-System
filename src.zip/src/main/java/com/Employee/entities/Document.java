package com.Employee.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "document")
public class Document {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "document_name")
	private String documentName;
	@Column(name = "document_no")
	private String documentNo;
	@ManyToOne
	@JoinColumn(name = "employee_id")
	private Employee employee;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Document(Long id, String documentName) {
		super();
		this.id = id;
		this.documentName = documentName;
	}

	public Document(String documentName, String documentNo) {
		super();
		this.documentName = documentName;
		this.documentNo = documentNo;
	}

	public Document(Long id, String documentName, String documentNo, Employee employee) {
		super();
		this.id = id;
		this.documentName = documentName;
		this.documentNo = documentNo;
		this.employee = employee;
	}

	public Document() {
		super();
		// TODO Auto-generated constructor stub
	}

}